import pygame
from charactor import character

pygame.init()


length = 1440
width = 3440
Running = True
PW = 200
PL = 250
WW = 320
WL = 200
                    #For Screen
screen = pygame.display.set_mode((width, length))
penguin = character("Weapon.png", "Penguin.png", 320, 200, 200, 300, width, length, screen)
                    #For Screen
pygame.display.set_caption("secondGame")
                    #For Backround
backround = pygame.image.load("Backround.png").convert()
BS = pygame .transform.scale(backround, (width + 1250, length))

while Running:

    MX, MY = pygame.mouse.get_pos()
    penguin.Facing(MX, MY)
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            Running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                Running = False

    screen.blit(BS, (0, 0))
    penguin.draw()


    pygame.display.flip()