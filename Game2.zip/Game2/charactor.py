import pygame
import math



# Charactor Stuff
class character:
    def __init__(self, Weapon, Penguin, WW, WL, PW, PL, width, length, screen):

        self.Weapon = Weapon

        self.Penguin = Penguin

        self.WW = WW

        self.WL = WL

        self.PW = PW

        self.PL = PL

        self.width = width

        self.length = length

        self.X = width/2 - PW/2

        self.Y = length/2 - PL/2

        self.screen = screen

        self.Penguin = pygame.image.load(Penguin)

        self.PS = pygame.transform.scale(self.Penguin, (PW, PL))

        self.OGP = self.PS

        self.Weapon = pygame.image.load(Weapon)

        self.WS = pygame.transform.scale(self.Weapon, (WW, WL))

    def draw(self):

        self.screen.blit(self.PS, (self.X, self.Y))

        self.screen.blit(self.WS, (self.X + 50, self.Y + 70))

    def Facing(self, MX, MY):

        PX = self.PW/2 + self.X

        PY = self.PL/2 + self.Y

        if PX == MX:
            Z = -90
        else:

            Z = math.atan((PY - MY)/(PX - MX))

            Z = math.degrees(Z)

            if MX <= PX:

                Z = 180 - Z

        self.PS = pygame.transform.rotate(self.OGP, Z)

        print("Z = ", Z)